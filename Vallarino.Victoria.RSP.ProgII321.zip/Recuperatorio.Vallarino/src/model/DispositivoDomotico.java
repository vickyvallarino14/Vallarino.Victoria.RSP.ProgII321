package model;

import java.util.Objects;


public class DispositivoDomotico implements Comparable<DispositivoDomotico>, CSVConvertible {
    private int codigo;
    private String nombreModelo;
    private Categoria categoria;
    private int consumoWatts;
    private int anioFabricacion;

    public DispositivoDomotico(int codigo, String nombreModelo, Categoria categoria, int consumoWatts, int anioFabricacion) {
        this.codigo = codigo;
        this.nombreModelo = nombreModelo;
        this.categoria = categoria;
        this.consumoWatts = consumoWatts;
        this.anioFabricacion = anioFabricacion;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNombreModelo() {
        return nombreModelo;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public int getConsumoWatts() {
        return consumoWatts;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }

    
    
    @Override
    public String toString() {
        return "DispositivoDomotico{" + "codigo=" + codigo + ", nombreModelo=" + nombreModelo + ", categoria=" + categoria + ", consumoWatts=" + consumoWatts + ", anioFabricacion=" + anioFabricacion + '}';
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(anioFabricacion);
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof DispositivoDomotico d)) {
            return false;
        }
        return this.anioFabricacion == d.anioFabricacion;
    }
    
    @Override
    public int compareTo(DispositivoDomotico o) {
        int cmp = Integer.compare(o.anioFabricacion, this.anioFabricacion);
        if(cmp == 0){
            cmp = Integer.compare(this.consumoWatts, o.consumoWatts);
        }
        return cmp;
    }

    @Override
    public String toCSV() {
        return codigo + "," + nombreModelo + "," + categoria + "," + consumoWatts + "," + anioFabricacion + "\n";
    }
    
    public static DispositivoDomotico fromCSV(String linea) {
        linea = linea.substring(0, linea.length());
        String[] datos = linea.split(",");
        return new DispositivoDomotico(Integer.parseInt(datos[0]), datos[1], Categoria.valueOf(datos[2]), Integer.parseInt(datos[3]), Integer.parseInt(datos[4]));
    }
    
    public static String toHeaderCSV(){
        return "codigo,nombreModelo,categoria,consumoWatts,anioFabricacion\n";
    }
}
