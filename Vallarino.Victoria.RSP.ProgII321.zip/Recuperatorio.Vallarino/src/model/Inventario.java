
package model;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;


public class Inventario<T extends CSVConvertible & Comparable<T>> implements Almacenable<T>, Serializable {

    private List<T> inventario = new ArrayList<>();
    
    @Override
    public void agregar(T elemento) {
        Objects.requireNonNull(elemento, "Elemento nulo");
        inventario.add(elemento);
    }

    @Override
    public void eliminarSegun(Predicate<T> criterio) {
        for (T item : inventario) {
            if (criterio.test(item)) {
                inventario.remove(item);
            }
        }
    }

    @Override
    public List<T> obtenerTodos() {
        return inventario;
    }

    @Override
    public T buscar(Predicate<T> criterio) {
        T toReturn = null;
        for(T e:inventario){
            if(criterio.test(e)){
                toReturn = e;
                return toReturn;
            }
        }
        return toReturn;
    }

    @Override
    public void ordenar() {
        inventario.sort((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        inventario.sort(comparador);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> toReturn = new ArrayList<>();
        for (T item : inventario) {
            if (criterio.test(item)) {
                toReturn.add(item);
            }
        }
        return toReturn;
    }

    @Override
    public List<T> transformar(Function<T, T> operador) {
        List<T> resultado = new ArrayList<>();
        for(T item: inventario){
            T nuevo = operador.apply(item);
            resultado.add(nuevo);
        }
        return resultado;
    }

    @Override
    public int contar(Predicate<T> criterio) {
        int c = 0;
        for(T e: inventario){
            if(criterio.test(e)){
                c++;
            }
        }
        return c;
    }

    @Override
    public void guardarEnBinario(String ruta) throws IOException {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(ruta))) {
            serializador.writeObject(inventario);
        }
    }

    @Override
    public void cargarDesdeBinario(String ruta) throws IOException, ClassNotFoundException {
        inventario.clear();
        try (ObjectInputStream desearializador = new ObjectInputStream(new FileInputStream(ruta))) {
            inventario = (List<T>) desearializador.readObject();
        }
    }

    @Override
    public void guardarEnCSV(String ruta) throws IOException {
         try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {
            for (T d : inventario) {
                escritor.write(((DispositivoDomotico) d).toCSV());
            }
        }
    }

    @Override
    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws Exception {
        inventario.clear();
        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                inventario.add(fromCSV.apply(linea));
            }
        }
    }

    @Override
    public void guardarEnJSON(String ruta) throws Exception {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        PrintWriter pw = new PrintWriter(new FileWriter(ruta));
        pw.println(gson.toJson(inventario));
        pw.close();
    }
    
}
