package model;

public enum DestinoTemporal {
    HILL_VALLEY_1955,
    HILL_VALLEY_1985,
    HILL_VALLEY_2015,
    FAR_WEST_1885,
    REALIDAD_ALTERNATIVA,
    LINEA_RESTAURADA

}
