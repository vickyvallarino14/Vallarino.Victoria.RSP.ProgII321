package model;

import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

public interface Inventariable<T> {

    void agregar(T viaje);

    T obtener(int indice);

    T eliminar(int indice);

    List<T> filtrar(Predicate<? super T> criterio);

    void ordenar();

    void ordenar(Comparator<? super T> cmp);

}
