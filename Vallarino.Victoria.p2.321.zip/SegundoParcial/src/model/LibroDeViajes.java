package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class LibroDeViajes<T extends CSVSerializable & Comparable<T>> implements Serializable, Inventariable<T> {

    private List<T> inventario = new ArrayList<>();

    @Override
    public void agregar(T viaje) {
        Objects.requireNonNull(viaje, "Elemento nulo");
        inventario.add(viaje);
    }

    private void validarIndice(int indice) {
        if (indice < 0 || indice > inventario.size()) {
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }

    @Override
    public T obtener(int indice) {
        validarIndice(indice);
        return inventario.get(indice);
    }

    @Override
    public T eliminar(int indice) {
        validarIndice(indice);
        return inventario.remove(indice);
    }

    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> toReturn = new ArrayList<>();
        for (T item : inventario) {
            if (criterio.test(item)) {
                toReturn.add(item);
            }
        }
        return toReturn;
    }

    @Override
    public void ordenar() {
        inventario.sort((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<? super T> cmp) {
        inventario.sort(cmp);
    }

    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path))) {
            serializador.writeObject(inventario);
        }
    }

    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        inventario.clear();
        try (ObjectInputStream desearializador = new ObjectInputStream(new FileInputStream(path))) {
            inventario = (List<T>) desearializador.readObject();
        }

    }

    public void guardarEnCSV(String path) throws IOException {

        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
            for (T v : inventario) {
                escritor.write(((ViajeTemporal) v).toCSV());
            }
        }

    }

    public void cargarDesdeCSV(String path, Function<String, T> accion) throws IOException {
        inventario.clear();
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                inventario.add(accion.apply(linea));
            }
        }
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T v : inventario) {
            accion.accept(v);
        }
    }

}
