package model;

public class ViajeTemporal implements Comparable<ViajeTemporal>, CSVSerializable {

    private static final long serialVersionUID = 1L;
    private int id;
    private String descripcion;
    private String viajero;
    private DestinoTemporal destino;

    public ViajeTemporal(int id, String descripcion, String viajero, DestinoTemporal destino) {
        this.id = id;
        this.descripcion = descripcion;
        this.viajero = viajero;
        this.destino = destino;
    }

    @Override
    public String toString() {
        return "ViajeTemporal{" + "id=" + id + ", descripcion=" + descripcion + ", viajero=" + viajero + ", destino=" + destino + '}';
    }

    public DestinoTemporal getDestino() {
        return destino;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getId() {
        return id;
    }

    public String getViajero() {
        return viajero;
    }

    @Override
    public int compareTo(ViajeTemporal o) {
        return Integer.compare(this.id, o.id);
    }

    @Override
    public String toCSV() {
        return id + "," + descripcion + "," + viajero + "," + destino + "\n";
    }

    public static ViajeTemporal fromCSV(String productoCSV) {
        productoCSV = productoCSV.substring(0, productoCSV.length());
        String[] datos = productoCSV.split(",");
        return new ViajeTemporal(Integer.parseInt(datos[0]), datos[1], datos[2], DestinoTemporal.valueOf(datos[3]));
    }

}
